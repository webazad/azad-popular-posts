=== Popular Post Widget ===

Contributors: itzmostafiz
Tags: popular post, popular posts, most popular posts, widget, popular post widget.
Requires at least: 4.0
Tested up to: 4.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Popular post widget is a simple widget to show your most popular posts based on views.

== Description ==

This is a simple widget like others to show your most popular posts based on views of your post. Put it in any of your widget area from your WordPress dashboard and the it will automatically show 5 most popular posts which will be visited most after the activation of the widget.So, after activation of the widget, visit a post of your website and see, it will show below the popular post title.

== Installation ==

/// Uploading in WordPress Dashboard

1. First download the plugin ZIP file from Wordpress website
2. Log in to your website administrator panel   
3. Go to the 'Add New' in the plugins dashboard, click �Upload Plugin�
4. Upload Popular Post Widget ZIP file by choosing it from your computer
5. Click **Install Now** button
6. Then click **Activate Plugin** button.
7. You can see the Popular post Widget in the widget section 'Appearance > widgets'.

/// Using The WordPress Plugin Dashboard

1. Go to the 'Add New' in the plugins dashboard
2. Search for 'Popular Post Widget'
3. Click **Install Now** button
4. Then click **Activate Plugin** button
5. You can see the Popular Post Widget in the widget section 'Appearance > widgets'.

/// Using FTP

1. Download the ZIP file from Wordpress website
2. Extract the **popular post widget** directory to your computer
3. Upload the **popular post widget** directory to the **/wp-content/plugins/** directory
4. Activate the plugin in the Plugin dashboard
5. You can see the Popular Post Widget in the widget section 'Appearance > widgets'.

Now put it into any widget area and set the widget are title then save. Now visit a post in your website, then it will show below the widget title you saved from the dashboard. Thus 5 most popular posts will show after visiting them.

== Frequently Asked Questions ==

= How to get the most recent version of the plugin? =

You will find update notification in your wordpress admin panel.

= How to use this plugin? =

See the description and also you can see the description over the Frequently Asked Questions.

== Screenshots ==
1. Initial front-end view of popular posts.


== Changelog ==

= 1.0 =
* Initial Release.

= 1.0.1 =
* Test for the new version (4.9.1) of WordPress.