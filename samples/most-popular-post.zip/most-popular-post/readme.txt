

























































































































































































































=== Most Popular Post Widget ===
Contributors: quazisazzad
Tags: most popular post, most viewed post
Requires at least: 3.0.1
Tested up to: 5.2.2
Stable tag: 1.3
Version: 2.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Shwon your most popular/viewed post with view count
== Description ==
This is a simple widget plugin to show most popular posts of your WordPress website based on views.You can easily control this plugin from dashboard.

***Featured***
*** post display by post view count/comment count
*** shown your most popular post

*** Shown the number of post as you wish

*** You can show/hide count of visit.

*** You can show/hide Author name.

*** You can show/hide  count of comment.

How to use:-
very easy to use,after active plugin  just go to appearance->widget. then add "Most popular post" anywhere your widget area. it's enough, Let's enjoy it.


== Installation ==

**The easy way.**

Go to your WordPress Dashboard. Navigate to Plugins > Add New and then search for "most popular post". Click on Install and then Activate the Plugin.

That's it, "most popular post is now activated on your site!

**The hard way..**

Download "most popular post"  and then extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.





== Frequently Asked Questions ==



== Screenshots ==

1.  /assets/screenshot-1.png
1.  /assets/screenshot-2.png

== Changelog ==
= 2.0 =
Add Another option
= 1.5 =
bug fix

= 1.0 =
*Initail Release

