=== Plugin Name ===

PostViews Count & Popular Posts Widgets
Contributors:raja3c
Tags: views, post views, wp popular posts, wp post views, post views count, Popular Posts Views 
Requires at least: 3.4.1
Tested up to: 4.8.1
Stable tag: 1.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html



TP WordPress Post Views Counter and Popular Posts Widget based on Post Views Plugin (TP WP Post Views) will help sites to add post views and show Popular posts in Sidebar or anywhere.


== Description ==



TP WordPress Post Views Counter and Popular Posts Widget Plugin based on Post Views (TP WP Post Views & Popular Post Plugin) will help sites to add post views and show Popular posts in Sidebar or anywhere. This Ajax based Plugin counts the Single Post views and Displays the View counts in all default post types. You can use this for in Custom Post Type too.

 This is best Popular WordPress Plugin using Pageviews and works with any kind of WordPress Blogs like Tech Blogs, Food Blogs, Auto Blogs and any other WordPress sites. Unlike Popular Posts based on comments, this plugin uses Pageviews and shows the Popular posts based on User visits.

 Using this plugin, Show the Popular Trening Posts to your users to get more pageviews.

== WordPress Popular Posts and Views Count Plugin Features ==

* Displays the Single Post View Counts in Posts, Pages and Home Pages.
* Popular Posts Widgets based Post Views Count
* Use it in Any WordPress Themes
* Compatible with Caching Plugins
* Shortcode
* Custom function call to use in themes
* Minimalist Design, Light weighted and very Fast.
* RTL Support
* Localization Support.





 


 

If you like this plugin then follow ThemePacific on [Twitter](http://twitter.com/themepacific "Twitter"), [Facebook](http://facebook.com/themepacific "Facebook"), and [Google+](https://plus.google.com/u/0/111626044701452949912 "Google+")

 





== Installation ==



Download the Plugin here. Extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.



 
 
 
== Changelog ==
 
= 1.1 =

*Initial Release

== Upgrade Notice ==

= 1.1 =

*Initial Release
