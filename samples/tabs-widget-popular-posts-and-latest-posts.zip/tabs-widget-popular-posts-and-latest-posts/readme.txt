=== Tabs popular posts and latest posts ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/
Author URI: http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/
Plugin URI: http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/
Tags:  Tabber, Widget, Plugin
Requires at least: 3.4
Tested up to: 5.3
Stable tag: 3.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This is a jquery based lightweight plugin to create a new wordpress tabbed widget to display recent posts and popular posts.

== Description ==

This is a jquery based lightweight plugin to create a new wordpress tabbed widget to display recent posts and popular posts.

Check official website for live demo [http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)

*   [Live Demo](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)		
*   [More information](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)		
*   [User Comments](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)

This is a jquery based lightweight plugin to create a new wordpress tabbed widget to display recent posts and popular posts.

**Advantage of this plugin**

*	Lightweight plugin
*	Smooth transitions between two tab
*	Easy configuration
*	Adjust number of posts to display tab
			
== Installation ==	

**Installation Instruction & Configuration**  	

[Installation Instruction and Configuration](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)

== Frequently Asked Questions ==

Q1 . Icons not showing on tabber tab? or Do you want to change the tabber icon image?

[Frequently Asked Questions](http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/)

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/

2. Admin Screen. http://www.gopiplus.com/work/2012/11/24/wordpress-plugin-tabs-widget-popular-posts-and-latest-posts/

== Upgrade Notice ==

= 1.0 =
			
First version	

= 2.0 =

Tested up to 3.6
Bug fixed on CSS, JS link

= 2.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (tabs-popular-vs-latest.po) available in the languages folder.

= 2.2 =

1. Tested up to 3.9

= 2.3 =

1. Tested up to 4.0
2. JS bug fixed.

= 2.4 =

1. Tested up to 4.1

= 2.5 =

1. Tested up to 4.2.2

= 2.6 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.
3. JS/CSS link bug fixed.

= 2.7 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 2.8 =

1. Tested up to 4.6

= 2.9 =

1. Tested up to 4.7

= 3.0 =

1. Tested up to 4.8

= 3.1 =

1. Tested up to 4.9

= 3.2 =

1. Tested up to 5.1
2. "Updating Failed" error message when adding plugin shortcode in Shortcode Block is fixed

= 3.3 =

1. Tested up to 5.2
2. Uninstall option added. All plugin reference and plugin table will be cleared during uninstallation.

= 3.4 =

1. Tested up to 5.3

== Changelog ==

= 1.0 =
			
First version

= 2.0 =

Tested up to 3.6
Bug fixed on CSS, JS link

= 2.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (tabs-popular-vs-latest.po) available in the languages folder.

= 2.2 =

1. Tested up to 3.9

= 2.3 =

1. Tested up to 4.0
2. JS bug fixed.

= 2.4 =

1. Tested up to 4.1

= 2.5 =

1. Tested up to 4.2.2

= 2.6 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.
3. JS/CSS link bug fixed.

= 2.7 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 2.8 =

1. Tested up to 4.6

= 2.9 =

1. Tested up to 4.7

= 3.0 =

1. Tested up to 4.8

= 3.1 =

1. Tested up to 4.9

= 3.2 =

1. Tested up to 5.1
2. "Updating Failed" error message when adding plugin shortcode in Shortcode Block is fixed

= 3.3 =

1. Tested up to 5.2
2. Uninstall option added. All plugin reference and plugin table will be cleared during uninstallation.

= 3.4 =

1. Tested up to 5.3