<?php
/**
* :: Description...
*/
defined('ABSPATH') || exit;

class Azad_Popular_Posts_Public{
    public function __construct(){
        
    }
    public function init(){}
    public function _get_instance(){}
    public function __destruct(){}
}