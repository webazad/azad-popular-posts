<?php
/**
* :: Description...
*/
defined('ABSPATH') || exit;

class Azad_Popular_Posts_Widget extends WP_Widget {
    public function __construct(){
        
    }
    public function init(){
    }
}
add_action('register_widgets','');