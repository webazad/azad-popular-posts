(function( $ ) {
	$(document).ready(function () {
    	$('.woo_amc_select_color').wpColorPicker();
    });
})( jQuery );
